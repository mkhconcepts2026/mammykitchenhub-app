import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { adminClient } from "@/lib/supabase/admin";
import { prepareEmployee } from "@/lib/employees/provisioning";

export async function POST(request: Request) {
  let authUserId: string | null = null;

  try {
    // ---------------------------------------
    // AUTHENTICATE REQUEST
    // ---------------------------------------

    const supabase = await createClient();

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      return NextResponse.json(
        {
          success: false,
          message: "Unauthorized.",
        },
        {
          status: 401,
        }
      );
    }

    // ---------------------------------------
    
       // AUTHORIZE HR-ONLY EMPLOYEE CREATION
    // Admin/COO role changes remain a separate workflow.

    const { data: callerRole, error: callerRoleError } =
      await (supabase as any).rpc("current_effective_app_role");

    const effectiveRole = String(callerRole ?? "").toUpperCase();

    if (callerRoleError || effectiveRole !== "HR") {
      return NextResponse.json(
        {
          success: false,
          message: "Forbidden. Only active HR users may create employee accounts.",
        },
        { status: 403 }
      );
    }

    // REQUEST BODY
    // ---------------------------------------


    const body = await request.json();

    const employee = await prepareEmployee(body);

    // ---------------------------------------
    // Get Role Name
    // ---------------------------------------

    const {
      data: role,
      error: roleError,
    } = await adminClient
      .from("employee_roles")
      .select("name, system_role")
      .eq("id", employee.roleId)
      .single();

    console.log("ROLE RECORD:", role);
    console.log("SYSTEM ROLE:", role?.system_role);

    if (roleError) {
      return NextResponse.json(
        {
          success: false,
          message: "Employee role could not be found.",
        },
        {
          status: 400,
        }
      );
    }

    // ---------------------------------------
    // Temporary Password
    // ---------------------------------------

    const temporaryPassword =
      `MKH${Math.floor(100000 + Math.random() * 900000)}!`;

    // ---------------------------------------
    // Create Auth User
    // ---------------------------------------

    const {
      data: authUser,
      error: authError,
    } = await adminClient.auth.admin.createUser({
      email: employee.email,
      password: temporaryPassword,
      email_confirm: true,
    });

    if (authError || !authUser.user) {
      return NextResponse.json(
        {
          success: false,
          message: authError?.message,
        },
        {
          status: 400,
        }
      );
    }

    authUserId = authUser.user.id;

    // ---------------------------------------
    // Create Profile FIRST
    // ---------------------------------------

    const { error: profileError } =
      await adminClient
        .from("profiles")
        .insert({
          id: authUserId,

          full_name:
            `${employee.firstName} ${employee.lastName}`,

          email:
            employee.email,

          //phone: employee.phone,

          username:
            employee.username,

          role:
            role.system_role,

          // NEW: Link profile to operational territory
          territory_id:
            employee.territoryId || null,

          // HR approval is required before login is allowed.
          status:
            "active",

          must_change_password:
            true,
        });

    if (profileError) {
      await adminClient.auth.admin.deleteUser(authUserId);

      return NextResponse.json(
        {
          success: false,
          message: profileError.message,
        },
        {
          status: 400,
        }
      );
    }

    // ---------------------------------------
    // Create Employee
    // ---------------------------------------

    const {
      data,
      error: employeeError,
    } = await adminClient
      .from("employees")
      .insert({
        profile_id: authUserId,

        employee_number:
          employee.employeeNumber,

        first_name:
          employee.firstName,

        last_name:
          employee.lastName,

        gender:
          employee.gender,

        nationality:
          employee.nationality,

        address:
          employee.address,

        //phone: employee.phone,

        photo_url:
          employee.photoUrl,

        department_id:
          employee.departmentId,

        role_id:
          employee.roleId,

        reports_to:
          employee.reportsTo || null,

        state_id:
          employee.stateId || null,

        lga_id:
          employee.lgaId || null,

        territory_id:
          employee.territoryId || null,

        office_location:
          employee.officeLocation || null,

        employment_type:
          employee.employmentType || "Full Time",

        hire_date:
          employee.hireDate || null,

        status:
          "active",

        employment_status:
          "Active",

        email:
          employee.email,

        username:
          employee.username,

        // SECURITY: use authenticated user, not browser-supplied createdBy
        created_by:
          user.id,
      })
      .select()
      .single();

    if (employeeError) {
      await adminClient
        .from("profiles")
        .delete()
        .eq("id", authUserId);

      await adminClient.auth.admin.deleteUser(
        authUserId
      );

      return NextResponse.json(
        {
          success: false,
          message: employeeError.message,
        },
        {
          status: 400,
        }
      );
    }

    // ---------------------------------------
    // Create Pending HR Approval Record
    // ---------------------------------------

    const { error: approvalError } = await (adminClient as any)
      .from("employee_approvals")
      .insert({
                employee_id: data.id,
        approval_status: "Approved",
        approved_by: user.id,
        approved_at: new Date().toISOString(),
      });

    if (approvalError) {
      console.error("Employee approval record creation failed:", approvalError);

      await adminClient
        .from("employees")
        .delete()
        .eq("id", data.id);

      await adminClient
        .from("profiles")
        .delete()
        .eq("id", authUserId);

      await adminClient.auth.admin.deleteUser(authUserId);

      return NextResponse.json(
        {
          success: false,
          message: "The employee approval record could not be created. No employee account was retained.",
        },
        {
          status: 500,
        }
      );
    }

    // ---------------------------------------
    // Delete Draft
    // ---------------------------------------

    await adminClient
      .from("employee_drafts")
      .delete()
      .eq("created_by", user.id)
      .eq("status", "draft");

    // ---------------------------------------
    // Success
    // ---------------------------------------

    return NextResponse.json({
      success: true,

      employee: data,

      credentials: {
        employeeNumber:
          employee.employeeNumber,

        fullName:
          `${employee.firstName} ${employee.lastName}`,

        username:
          employee.username,

        loginId:
          employee.email,

        temporaryPassword,
      },
    });

  } catch (error: any) {

    if (authUserId) {

      await adminClient
        .from("profiles")
        .delete()
        .eq("id", authUserId);

      await adminClient.auth.admin.deleteUser(
        authUserId
      );
    }

    console.error(error);

    return NextResponse.json(
      {
        success: false,
        message:
          error.message ||
          "Employee creation failed.",
      },
      {
        status: 500,
      }
    );
  }
}