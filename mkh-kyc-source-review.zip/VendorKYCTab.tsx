"use client";

type VendorKYCTabProps = {
  kycStatus: string;
};

export default function VendorKYCTab({
  kycStatus,
}: VendorKYCTabProps) {
  const status = (kycStatus || "Not Submitted").trim();
  const normalizedStatus = status.toLowerCase();

  const tone =
    normalizedStatus === "verified" || normalizedStatus === "approved"
      ? {
          indicator: "bg-emerald-500",
          badge: "border-emerald-200 bg-emerald-50 text-emerald-700",
          panel: "border-emerald-200 bg-emerald-50/60",
        }
      : normalizedStatus === "pending" || normalizedStatus === "pending review"
        ? {
            indicator: "bg-amber-500",
            badge: "border-amber-200 bg-amber-50 text-amber-700",
            panel: "border-amber-200 bg-amber-50/60",
          }
        : normalizedStatus === "not submitted"
          ? {
              indicator: "bg-slate-400",
              badge: "border-slate-200 bg-slate-50 text-slate-700",
              panel: "border-slate-200 bg-slate-50",
            }
          : normalizedStatus === "rejected" || normalizedStatus === "requires attention"
            ? {
                indicator: "bg-red-500",
                badge: "border-red-200 bg-red-50 text-red-700",
                panel: "border-red-200 bg-red-50/60",
              }
            : {
                indicator: "bg-blue-500",
                badge: "border-blue-200 bg-blue-50 text-blue-700",
                panel: "border-blue-200 bg-blue-50/60",
              };

  return (
    <section className="space-y-6">
      <header>
        <p className="mb-2 text-xs font-bold uppercase tracking-[0.24em] text-orange-600">
          Account compliance
        </p>
        <h1 className="text-3xl font-bold tracking-tight md:text-4xl">
          KYC Verification
        </h1>
        <p className="mt-2 text-base text-slate-500">
          View the current verification status for your vendor account.
        </p>
      </header>

      <div className={`rounded-2xl border p-6 shadow-sm md:p-8 ${tone.panel}`}>
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <span
              aria-hidden="true"
              className={`mt-1.5 h-3 w-3 shrink-0 rounded-full ${tone.indicator}`}
            />
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                Current verification status
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                This status reflects the latest saved KYC record.
              </p>
            </div>
          </div>

          <span
            className={`inline-flex w-fit items-center rounded-full border px-4 py-2 text-sm font-semibold ${tone.badge}`}
            role="status"
            aria-live="polite"
          >
            {status}
          </span>
        </div>
      </div>
    </section>
  );
}
