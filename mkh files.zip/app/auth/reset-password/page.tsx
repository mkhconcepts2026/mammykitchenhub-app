export default function ForgotPasswordPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <h1 className="text-2xl font-bold">
        Forgot Password - Coming Soon
      </h1>
    </div>
  );
}